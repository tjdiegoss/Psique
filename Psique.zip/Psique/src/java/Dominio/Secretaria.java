/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author Diego
 */
public class Secretaria extends Usuario{

    public Secretaria(Login login, String nome) {
        super(login, nome);
    }
    
    
    
}
