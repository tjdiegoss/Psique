/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author Diego
 */
public class Psicologo extends Usuario{

    public Psicologo(Login login, String nome) {
        super(login, nome);
    }
    
    
    
}
