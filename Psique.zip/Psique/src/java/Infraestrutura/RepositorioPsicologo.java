/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Infraestrutura;

import Dominio.Psicologo;
import java.util.ArrayList;

/**
 *
 * @author Diego
 */
public class RepositorioPsicologo implements InterfaceRepositorios<Psicologo> {

    @Override
    public void cadastrar(Psicologo t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList<Psicologo> consultar() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList<Psicologo> consultarNome(String s) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void atualizar(Psicologo t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void deletar(Psicologo t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
