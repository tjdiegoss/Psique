/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Infraestrutura;

import Dominio.Secretaria;
import java.util.ArrayList;

/**
 *
 * @author Diego
 */
public class RepositorioSecretaria implements InterfaceRepositorios<Secretaria> {

    @Override
    public void cadastrar(Secretaria t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList<Secretaria> consultar() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList<Secretaria> consultarNome(String s) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void atualizar(Secretaria t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void deletar(Secretaria t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
